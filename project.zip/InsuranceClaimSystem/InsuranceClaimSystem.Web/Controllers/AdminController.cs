using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using InsuranceClaimSystem.Data.Models;
 
namespace InsuranceClaimSystem.Web.Controllers
{
    public class AdminController : Controller
    {
        private readonly IHttpClientFactory _factory;
        private readonly IConfiguration _config;
 
        public AdminController(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _config = config;
        }
 
        // GET: /Admin/Index
        public async Task<IActionResult> Index(string? status)
        {
            var client = _factory.CreateClient("api");
            var res = await client.GetAsync("api/claims/all");
 
            if (!res.IsSuccessStatusCode)
            {
                ViewBag.CurrentStatus = status ?? "All";
                return View(new List<Claim>());
            }
 
            var list = await res.Content.ReadFromJsonAsync<List<Claim>>() ?? new List<Claim>();
 
            // 🔹 Apply status filter if selected
            if (!string.IsNullOrEmpty(status) && status != "All")
            {
                list = list
                    .Where(c => c.Status.Equals(status, StringComparison.OrdinalIgnoreCase))
                    .ToList();
            }
 
            ViewBag.CurrentStatus = status ?? "All"; // to keep dropdown selected
 
            return View(list);
        }
 
        // POST: /Admin/UpdateStatus
        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, string status, string remarks)
        {
            var client = _factory.CreateClient("api");
 
            var dto = new
            {
                Status = status,
                Remarks = remarks,
                AdminUser = HttpContext.Session.GetString("Username") ?? "admin"
            };
 
            var adminSecret = _config["AdminSecret"] ?? "AdminSecret123";
 
            var res = await client.PutAsJsonAsync(
                $"api/claims/{id}/status?adminSecret={Uri.EscapeDataString(adminSecret)}",
                dto
            );
 
            var content = await res.Content.ReadAsStringAsync(); // useful for debugging/logging
 
            if (!res.IsSuccessStatusCode)
            {
                TempData["Error"] = $"Failed: {res.StatusCode} - {content}";
            }
            else
            {
                TempData["Success"] = $"Updated successfully: {content}";
            }
 
            return RedirectToAction("Index");
        }
    }
}