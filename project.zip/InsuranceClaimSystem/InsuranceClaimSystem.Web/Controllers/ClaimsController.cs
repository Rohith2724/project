using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using InsuranceClaimSystem.Data.Models;

namespace InsuranceClaimSystem.Web.Controllers;
public class ClaimsController : Controller
{
    private readonly IHttpClientFactory _factory;
    public ClaimsController(IHttpClientFactory factory) { _factory = factory; }

    public async Task<IActionResult> Index()
    {
        var role = HttpContext.Session.GetString("Role") ?? "User";
        var client = _factory.CreateClient("api");
        if (role == "Admin") return RedirectToAction("Index", "Admin");

        var uid = HttpContext.Session.GetString("UserId");
        if (uid == null) return RedirectToAction("Login", "Account");
        var res = await client.GetAsync($"api/claims/user/{uid}");
        if (!res.IsSuccessStatusCode) return View(new List<Claim>());
        var list = await res.Content.ReadFromJsonAsync<List<Claim>>() ?? new List<Claim>();
        return View(list);
    }

    public IActionResult Submit() => View();
    [HttpPost]
    public async Task<IActionResult> Submit(string policyName, string incidentDescription, decimal claimAmount, IFormFile? document)
    {
        var uid = HttpContext.Session.GetString("UserId");
        var username = HttpContext.Session.GetString("Username") ?? "";
        if (uid == null) return RedirectToAction("Login", "Account");

        var client = _factory.CreateClient("api");
        var content = new MultipartFormDataContent();
        content.Add(new StringContent(uid), "userId");
        content.Add(new StringContent(username), "userName");
        content.Add(new StringContent(policyName), "policyName");
        content.Add(new StringContent(incidentDescription), "incidentDescription");
        content.Add(new StringContent(claimAmount.ToString()), "claimAmount");
        if (document != null && document.Length > 0)
        {
            var ms = new MemoryStream();
            await document.CopyToAsync(ms);
            ms.Position = 0;
            var fileContent = new StreamContent(ms);
            fileContent.Headers.ContentType = new MediaTypeHeaderValue(document.ContentType ?? "application/octet-stream");
            content.Add(fileContent, "document", document.FileName);
        }
        var res = await client.PostAsync("api/claims/submit", content);
        return RedirectToAction("Index");
    }
}