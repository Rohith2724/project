using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using InsuranceClaimSystem.Data.Models;

namespace InsuranceClaimSystem.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly IHttpClientFactory _factory;
        private readonly IConfiguration _config;

        public AccountController(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _config = config;
        }

        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(string Username, string Password, string Role)
        {
            var client = _factory.CreateClient("api");
            var model = new User
            {
                Username = Username,
                Password = Password,
                Role = Role
            };

            var res = await client.PostAsJsonAsync("api/auth/register", model);

            if (!res.IsSuccessStatusCode)
            {
                ViewBag.Error = await res.Content.ReadAsStringAsync();
                return View();
            }

            return RedirectToAction("Login");
        }

        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password, string role, string? secretKey)
        {
            var client = _factory.CreateClient("api");
            var res = await client.PostAsJsonAsync("api/auth/login", new User
            {
                Username = username,
                Password = password,
                Role = role // Include role for validation
            });

            if (!res.IsSuccessStatusCode)
            {
                ViewBag.Error = await res.Content.ReadAsStringAsync();
                return View();
            }

            var user = await res.Content.ReadFromJsonAsync<User>();
            if (user == null)
            {
                ViewBag.Error = "Invalid response";
                return View();
            }

            if (role == "Admin")
            {
                var cfg = _config["AdminSecret"] ?? "AdminSecret123";
                if (secretKey != cfg)
                {
                    ViewBag.Error = "Invalid admin secret";
                    return View();
                }
            }

            HttpContext.Session.SetString("UserId", user.Id.ToString());
            HttpContext.Session.SetString("Username", user.Username);
            HttpContext.Session.SetString("Role", user.Role);

            return user.Role == "Admin" ? RedirectToAction("Index", "Admin") : RedirectToAction("Index", "Claims");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
