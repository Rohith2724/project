using System;
using System.Collections.Generic;
namespace InsuranceClaimSystem.Data.Models;
public class Claim
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public string UserName { get; set; } = string.Empty;
    public string PolicyName { get; set; } = string.Empty;
    public string IncidentDescription { get; set; } = string.Empty;
    public decimal ClaimAmount { get; set; }
    public string Status { get; set; } = "Pending";
    public List<StatusUpdate> Updates { get; set; } = new();
    public string DocumentPath { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}