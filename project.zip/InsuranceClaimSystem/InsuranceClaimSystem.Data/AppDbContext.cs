using Microsoft.EntityFrameworkCore;
using System.Text.Json;
using InsuranceClaimSystem.Data.Models;

namespace InsuranceClaimSystem.Data
{
    public class AppDbContext : DbContext
    {
        private static string UsersFilePath => Path.Combine(Directory.GetCurrentDirectory(), "DataFiles", "users.json");
        private static string ClaimsFilePath => Path.Combine(Directory.GetCurrentDirectory(), "DataFiles", "claims.json");

        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; } = null!;
        public DbSet<Claim> Claims { get; set; } = null!;
        public DbSet<StatusUpdate> Updates { get; set; } = null!; // ✅ Added for EF tracking

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Claim>()
                .HasMany(c => c.Updates)
                .WithOne()
                .OnDelete(DeleteBehavior.Cascade);
        }

        public void EnsureJsonDataLoaded()
        {
            var dir = Path.Combine(Directory.GetCurrentDirectory(), "DataFiles");
            if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
            if (!File.Exists(UsersFilePath)) File.WriteAllText(UsersFilePath, "[]");
            if (!File.Exists(ClaimsFilePath)) File.WriteAllText(ClaimsFilePath, "[]");

            var usersJson = File.ReadAllText(UsersFilePath);
            var claimsJson = File.ReadAllText(ClaimsFilePath);

            var users = JsonSerializer.Deserialize<List<User>>(usersJson) ?? new List<User>();
            var claims = JsonSerializer.Deserialize<List<Claim>>(claimsJson) ?? new List<Claim>();

            if (!Users.Any())
            {
                Users.AddRange(users);
                base.SaveChanges();
            }
            if (!Claims.Any())
            {
                Claims.AddRange(claims);
                base.SaveChanges();
            }
        }

        private void PersistToJson()
        {
            var opt = new JsonSerializerOptions { WriteIndented = true };
            var users = Users.ToList(); // ✅ Removed AsNoTracking
            var claims = Claims.Include(c => c.Updates).ToList(); // ✅ Include Updates
            File.WriteAllText(UsersFilePath, JsonSerializer.Serialize(users, opt));
            File.WriteAllText(ClaimsFilePath, JsonSerializer.Serialize(claims, opt));
        }

        public override int SaveChanges()
        {
            var res = base.SaveChanges();
            PersistToJson(); // ✅ Persist after saving
            return res;
        }

        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            var res = await base.SaveChangesAsync(cancellationToken);
            PersistToJson(); // ✅ Persist after saving
            return res;
        }
    }
}
