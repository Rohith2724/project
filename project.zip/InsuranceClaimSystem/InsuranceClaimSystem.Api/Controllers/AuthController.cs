using Microsoft.AspNetCore.Mvc;
using InsuranceClaimSystem.Data;
using InsuranceClaimSystem.Data.Models;
using System.Linq;

namespace InsuranceClaimSystem.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _db;
        public AuthController(AppDbContext db) => _db = db;

        [HttpPost("register")]
        public IActionResult Register([FromBody] User user)
        {
            if (_db.Users.Any(u => u.Username.ToLower() == user.Username.ToLower()))
                return BadRequest("User exists");

            user.Id = _db.Users.Any() ? _db.Users.Max(u => u.Id) + 1 : 1;

            // Ensure role is set (default to User if not provided)
            user.Role = string.IsNullOrWhiteSpace(user.Role) ? "User" : user.Role;

            _db.Users.Add(user);
            _db.SaveChanges();
            return Ok(user);
        }

        [HttpPost("login")]
        public IActionResult Login([FromBody] User creds)
        {
            var user = _db.Users.FirstOrDefault(u =>
                u.Username == creds.Username &&
                u.Password == creds.Password);

            if (user == null)
                return Unauthorized("Invalid credentials");

            // Validate role match
            if (!string.Equals(user.Role, creds.Role, System.StringComparison.OrdinalIgnoreCase))
                return Unauthorized($"You are registered as '{user.Role}', not '{creds.Role}'.");

            return Ok(user);
        }
    }
}
