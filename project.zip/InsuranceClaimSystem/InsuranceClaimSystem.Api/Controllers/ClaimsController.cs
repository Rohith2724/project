using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using InsuranceClaimSystem.Data;
using InsuranceClaimSystem.Data.Models;
using System.Linq;
 
namespace InsuranceClaimSystem.Api.Controllers;
 
[ApiController]
[Route("api/[controller]")]
public class ClaimsController : ControllerBase
{
    private readonly AppDbContext _db;
    private readonly IWebHostEnvironment _env;
    private readonly IConfiguration _config;
 
    public ClaimsController(AppDbContext db, IWebHostEnvironment env, IConfiguration config)
    {
        _db = db;
        _env = env;
        _config = config;
    }
 
    [HttpPost("submit")]
    public async Task<IActionResult> Submit(
        [FromForm] int userId,
        [FromForm] string userName,
        [FromForm] string policyName,
        [FromForm] string incidentDescription,
        [FromForm] decimal claimAmount,
        IFormFile? document)
    {
        string docPath = string.Empty;
        if (document != null && document.Length > 0)
        {
            var uploads = Path.Combine(_env.WebRootPath ?? Path.Combine(Directory.GetCurrentDirectory(), "wwwroot"), "uploads");
            Directory.CreateDirectory(uploads);
            var safe = Path.GetRandomFileName() + Path.GetExtension(document.FileName);
            var full = Path.Combine(uploads, safe);
            using var stream = System.IO.File.Create(full);
            await document.CopyToAsync(stream);
            docPath = "/uploads/" + safe;
        }
 
        var claim = new Claim
        {
            Id = _db.Claims.Any() ? _db.Claims.Max(c => c.Id) + 1 : 1,
            UserId = userId,
            UserName = userName,
            PolicyName = policyName,
            IncidentDescription = incidentDescription,
            ClaimAmount = claimAmount,
            DocumentPath = docPath,
            Status = "Pending",
            CreatedAt = DateTime.UtcNow,
            Updates = new List<StatusUpdate>() 
        };
 
        _db.Claims.Add(claim);
        _db.SaveChanges();
        return Ok(claim);
    }
 
    [HttpGet("user/{userId}")]
    public IActionResult GetUserClaims(int userId)
    {
        var list = _db.Claims
            .Include(c => c.Updates) //  include remarks
            .Where(c => c.UserId == userId)
            .OrderByDescending(c => c.CreatedAt)
            .ToList();
 
        return Ok(list);
    }
 
    [HttpGet("all")]
    public IActionResult GetAllClaims()
    {
        var list = _db.Claims
            .Include(c => c.Updates) // include remarks
            .OrderByDescending(c => c.CreatedAt)
            .ToList();
 
        return Ok(list);
    }
 
    public class UpdateStatusDto
    {
        public string Status { get; set; } = "";
        public string Remarks { get; set; } = "";
        public string AdminUser { get; set; } = "";
    }
 
    [HttpPut("{id}/status")]
    public IActionResult UpdateStatus(int id, [FromBody] UpdateStatusDto dto, [FromQuery] string? adminSecret)
    {
        Console.WriteLine($"[API] UpdateStatus called for Claim {id}");
        Console.WriteLine($"[API] Received Status = {dto?.Status}, Remarks = {dto?.Remarks}, AdminUser = {dto?.AdminUser}");
        Console.WriteLine($"[API] adminSecret = {adminSecret}");
 
        var cfg = _config["AdminSecret"] ?? "AdminSecret123";
        if (string.IsNullOrEmpty(adminSecret) || adminSecret != cfg)
        {
            Console.WriteLine("[API] Admin secret invalid");
            return Forbid();
        }
 
        var claim = _db.Claims.Include(c => c.Updates).FirstOrDefault(c => c.Id == id);
        if (claim == null)
        {
            Console.WriteLine("[API] Claim not found");
            return NotFound();
        }
 
        claim.Status = dto.Status;
        claim.Updates.Add(new StatusUpdate
        {
            Status = dto.Status,
            Remarks = dto.Remarks,
            UpdatedBy = dto.AdminUser,
            UpdatedAt = DateTime.UtcNow
        });
 
        _db.SaveChanges();
        Console.WriteLine("[API] Claim updated successfully");
 
        return Ok(claim);
    }
}