using Microsoft.AspNetCore.Mvc;
using System.Net.Http.Json;
using InsuranceClaimSystem.Data.Models;
using System.Text.Json;

namespace InsuranceClaimSystem.Web.Controllers;
public class AccountController : Controller
{
    private readonly IHttpClientFactory _factory;
    private readonly IConfiguration _config;
    public AccountController(IHttpClientFactory factory, IConfiguration config) { _factory = factory; _config = config; }

    public IActionResult Register() => View();
    [HttpPost]
    public async Task<IActionResult> Register(User model)
    {
        try
        {
            var client = _factory.CreateClient("api");
            var res = await client.PostAsJsonAsync("api/auth/register", model);
            if (!res.IsSuccessStatusCode) { ViewBag.Error = await res.Content.ReadAsStringAsync(); return View(); }
            return RedirectToAction("Login");
        }
        catch(Exception ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

    public IActionResult Login() => View();
    [HttpPost]
    public async Task<IActionResult> Login(string username, string password, string role, string? secretKey)
    {
        try
        {
            var client = _factory.CreateClient("api");
            var res = await client.PostAsJsonAsync("api/auth/login", new { Username = username, Password = password });
            if (!res.IsSuccessStatusCode) { ViewBag.Error = "Invalid username/password"; return View(); }
            var payload = await res.Content.ReadFromJsonAsync<Dictionary<string, object>>();
            if (payload == null || !payload.ContainsKey("token")) { ViewBag.Error = "Invalid response"; return View(); }
            var token = payload["token"].ToString();
            var roleStr = payload.ContainsKey("role") ? payload["role"].ToString() : "User";
            HttpContext.Session.SetString("JWToken", token ?? "");
            HttpContext.Session.SetString("Role", roleStr ?? "User");
            HttpContext.Session.SetString("Username", username);
            return roleStr == "Admin" ? RedirectToAction("Index","Admin") : RedirectToAction("Index","Claims");
        }
        catch(Exception ex)
        {
            ViewBag.Error = ex.Message;
            return View();
        }
    }

    public IActionResult Logout() { HttpContext.Session.Clear(); return RedirectToAction("Login"); }
}