using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Net.Http.Json;
using InsuranceClaimSystem.Data.Models;
using System.Text.Json;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace InsuranceClaimSystem.Web.Controllers
{
    public class AccountController : Controller
    {
        private readonly IHttpClientFactory _factory;
        private readonly IConfiguration _config;
        private readonly ILogger<AccountController> _logger;

        public AccountController(IHttpClientFactory factory, IConfiguration config, ILogger<AccountController> logger)
        {
            _factory = factory;
            _config = config;
            _logger = logger;
        }

        public IActionResult Register() => View();

        [HttpPost]
        public async Task<IActionResult> Register(User model)
        {
            try
            {
                var client = _factory.CreateClient("api");
                var res = await client.PostAsJsonAsync("api/auth/register", model);
                if (!res.IsSuccessStatusCode)
                {
                    ViewBag.Error = await res.Content.ReadAsStringAsync();
                    return View();
                }
                return RedirectToAction("Login");
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
        }

        public IActionResult Login() => View();

        [HttpPost]
        public async Task<IActionResult> Login(string username, string password, string role, string? secretKey)
        {
            _logger.LogInformation("Login started for user: {Username}", username);

            try
            {
                var client = _factory.CreateClient("api");
                var res = await client.PostAsJsonAsync("api/auth/login", new { Username = username, Password = password });

                _logger.LogInformation("API response status: {StatusCode}", res.StatusCode);

                if (!res.IsSuccessStatusCode)
                {
                    _logger.LogWarning("Login failed for user: {Username}", username);
                    ViewBag.Error = "Invalid username/password";
                    return View();
                }

                var payload = await res.Content.ReadFromJsonAsync<Dictionary<string, object>>();
                if (payload == null || !payload.ContainsKey("token"))
                {
                    _logger.LogError("Token missing in response for user: {Username}", username);
                    ViewBag.Error = "Invalid response";
                    return View();
                }

                var token = payload["token"]?.ToString();
                var roleStr = payload.ContainsKey("role") ? payload["role"]?.ToString() : "User";
                var userId = payload.ContainsKey("userId") ? payload["userId"]?.ToString() : "";

                // Store in session
                HttpContext.Session.SetString("JWToken", token ?? "");
                HttpContext.Session.SetString("Role", roleStr ?? "User");
                HttpContext.Session.SetString("Username", username);
                HttpContext.Session.SetString("UserId", userId ?? "");

                // Sign in using cookie authentication
                var claims = new List<System.Security.Claims.Claim>
                {
                    new System.Security.Claims.Claim(ClaimTypes.Name, username),
                    new System.Security.Claims.Claim(ClaimTypes.Role, roleStr ?? "User")
                };

                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var principal = new ClaimsPrincipal(identity);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);

                _logger.LogInformation("Login successful for user: {Username}, role: {Role}", username, roleStr);

                return roleStr == "Admin" ? RedirectToAction("Index", "Admin") : RedirectToAction("Index", "Claims");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Exception during login for user: {Username}", username);
                ViewBag.Error = ex.Message;
                return View();
            }
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
