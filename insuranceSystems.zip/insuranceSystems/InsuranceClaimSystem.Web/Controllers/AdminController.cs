using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using System.Net.Http.Json;
using InsuranceClaimSystem.Data.Models;

namespace InsuranceClaimSystem.Web.Controllers
{
    [Authorize(Roles = "Admin")] 
    public class AdminController : Controller
    {
        private readonly IHttpClientFactory _factory;
        private readonly IConfiguration _config;

        public AdminController(IHttpClientFactory factory, IConfiguration config)
        {
            _factory = factory;
            _config = config;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var client = _factory.CreateClient("api");
                var token = HttpContext.Session.GetString("JWToken");
                if (!string.IsNullOrEmpty(token))
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                var res = await client.GetAsync("api/claims/all");
                if (!res.IsSuccessStatusCode)
                    return View(new List<Claim>());

                var list = await res.Content.ReadFromJsonAsync<List<Claim>>() ?? new List<Claim>();
                return View(list);
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
                return View(new List<Claim>());
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateStatus(int id, string status, string remarks)
        {
            try
            {
                var client = _factory.CreateClient("api");
                var token = HttpContext.Session.GetString("JWToken");
                if (!string.IsNullOrEmpty(token))
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);

                var dto = new
                {
                    Status = status,
                    Remarks = remarks,
                    AdminUser = HttpContext.Session.GetString("Username") ?? "admin"
                };

                var res = await client.PutAsJsonAsync($"api/claims/{id}/status", dto);
                if (!res.IsSuccessStatusCode)
                    TempData["Error"] = $"Failed: {res.StatusCode}";
                else
                    TempData["Success"] = "Claim updated";

                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction("Index");
            }
        }
    }
}
