using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace InsuranceClaimSystem.Data.Models
{
    public class Claim
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "User ID is required.")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "User name is required.")]
        [StringLength(100, ErrorMessage = "User name can't exceed 100 characters.")]
        public string UserName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Policy name is required.")]
        [StringLength(100, ErrorMessage = "Policy name can't exceed 100 characters.")]
        public string PolicyName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Incident description is required.")]
        [StringLength(1000, ErrorMessage = "Description can't exceed 1000 characters.")]
        public string IncidentDescription { get; set; } = string.Empty;

        [Required(ErrorMessage = "Claim amount is required.")]
        [Range(100, 1000000, ErrorMessage = "Claim amount must be between 100 and 1,000,000.")]
        public decimal ClaimAmount { get; set; }

        [Required]
        [StringLength(50)]
        public string Status { get; set; } = "Pending";

        public List<StatusUpdate> Updates { get; set; } = new();

        [StringLength(255, ErrorMessage = "Document path can't exceed 255 characters.")]
        public string DocumentPath { get; set; } = string.Empty;

        [DataType(DataType.DateTime)]
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
