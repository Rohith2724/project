using System.ComponentModel.DataAnnotations;

namespace InsuranceClaimSystem.Data.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Username is required.")]
        [StringLength(50, ErrorMessage = "Username can't exceed 50 characters.")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password is required.")]
        [StringLength(100, MinimumLength = 3, ErrorMessage = "Password must be at least 3 characters.")]
        public string Password { get; set; } = string.Empty;

        public string Role { get; set; } = "User";
    }
}
