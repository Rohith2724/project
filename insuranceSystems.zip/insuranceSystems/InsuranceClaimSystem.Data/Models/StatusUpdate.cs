using System;

namespace InsuranceClaimSystem.Data.Models
{
    public class StatusUpdate
    {
        public int Id { get; set; } 

        public string Status { get; set; } = string.Empty;
        public string Remarks { get; set; } = string.Empty;
        public string UpdatedBy { get; set; } = string.Empty;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;
    }
}
